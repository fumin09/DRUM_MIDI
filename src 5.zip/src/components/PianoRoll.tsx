// components/PianoRoll.tsx
import React, { useRef } from "react";
import Sketch from "react-p5";
import p5 from "p5";
import { Midi } from "@tonejs/midi";
import * as Tone from "tone";
import { pianoRollSetting, noteColors } from "../constants/settings";

type PianoRollProps = {
  midiDataRef: React.MutableRefObject<Midi | null>;
  isPlaying: boolean;
  startTime: number;
  bpm: number;
};

const PianoRoll: React.FC<PianoRollProps> = ({
  midiDataRef,
  isPlaying,
  startTime,
  bpm,
}) => {
  const drawnNotesRef = useRef<Set<string>>(new Set());

  const setup = (p: p5, parent: Element) => {
    p.createCanvas(p.windowWidth, pianoRollSetting.height).parent(parent);
    p.rectMode(p.CENTER);
    p.background(noteColors.background);
  };

  const draw = (p: p5) => {
    p.background(noteColors.background);

    const frame = {
      x: 100,                  // 左端 (px)
      y: pianoRollSetting.yOffset,  // 上端 (今のyオフセットと合わせてもいい)
      width: p.width - 200,     // 表示範囲の幅
      height: pianoRollSetting.height, 
    };

    p.push();
    p.background(noteColors.background);
    

    if (!isPlaying || !midiDataRef.current) return;

    const scrollSpeed = (bpm / 60) * pianoRollSetting.pixelsPerBeat;
    const now = Tone.now(); // 秒単位
    const currentTime = now - startTime; // startTime も秒なのでOK
    const notesDrawn = drawnNotesRef.current;

    p.push();
    p.translate(0, pianoRollSetting.yOffset); // ✅ 必ず height より小さく！

    midiDataRef.current.tracks.forEach((track, trackIndex) => {
      track.notes.forEach((note, noteIndex) => {
        const noteStart = note.time;
        

        if (noteStart > currentTime) return;


        const noteKey = `${trackIndex}-${noteIndex}`;

          // ✅ すでに描いたノートはスキップ

        const elapsed = currentTime - noteStart; // ★経過時間で線画
        const duration = note.duration;
        const drawDuration = Math.min(elapsed, duration);

        const x = frame.x + noteStart * scrollSpeed;
        const w = drawDuration * scrollSpeed; // drawDuration分だけ伸ばす！
        const y = p.map(
          note.midi,
          pianoRollSetting.minMidi,
          pianoRollSetting.maxMidi,
          p.height,
          0
        );
        const h = pianoRollSetting.noteHeight;
        // ✅ 左端チェック（ノートのx座標）
        if (x < frame.x) return;

        p.fill(noteColors.default);
        p.noStroke();
        p.rect(x, y, w, h);

        notesDrawn.add(noteKey);
      });
    });

    p.stroke(noteColors.border);
    for (
      let midi = pianoRollSetting.minMidi;
      midi <= pianoRollSetting.maxMidi;
      midi += 12
    ) {
      const y = p.map(
        midi,
        pianoRollSetting.minMidi,
        pianoRollSetting.maxMidi,
        p.height,
        0
      );
      p.line(frame.x, y, frame.x + frame.width, y);
    }

    p.pop();
  };

  return <Sketch setup={setup} draw={draw} />;
};

export default PianoRoll;
