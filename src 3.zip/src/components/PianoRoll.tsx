// components/PianoRoll.tsx
import React, { useRef } from "react";
import Sketch from "react-p5";
import p5 from "p5";
import { Midi } from "@tonejs/midi";
import { pianoRollSetting, noteColors } from "../constants/settings";

type PianoRollProps = {
  midiDataRef: React.MutableRefObject<Midi | null>;
  isPlaying: boolean;
  startTime: number;
  bpm: number;
};

const PianoRoll: React.FC<PianoRollProps> = ({
  midiDataRef,
  isPlaying,
  startTime,
  bpm,
}) => {
  const drawnNotesRef = useRef<Set<string>>(new Set());

  const setup = (p: p5, parent: Element) => {
    p.createCanvas(p.windowWidth, pianoRollSetting.height).parent(parent);
    p.rectMode(p.CENTER);
    p.background(noteColors.background);
    
  };

  const draw = (p: p5) => {
    
    p.background(noteColors.background);
    if (!isPlaying || !midiDataRef.current) return;

    const scrollSpeed = (bpm / 60) * pianoRollSetting.pixelsPerBeat;
    const now = p.millis();
    const currentTime = (now - startTime) / 1000;
    const notesDrawn = drawnNotesRef.current;

    p.push();
    p.translate(0, pianoRollSetting.yOffset); // 🎯 位置調整！

    midiDataRef.current.tracks.forEach((track, trackIndex) => {
      track.notes.forEach((note, noteIndex) => {
        const noteStart = note.time;
        const noteEnd = note.time + note.duration;
        if (noteEnd < currentTime) return;

        const noteKey = `${trackIndex}-${noteIndex}`;
        const x = p.width - (noteStart - currentTime) * scrollSpeed;
        const w = note.duration * scrollSpeed;
        const y = p.map(
          note.midi,
          pianoRollSetting.minMidi,
          pianoRollSetting.maxMidi,
          p.height,
          0
        );
        const h = pianoRollSetting.noteHeight;

        p.fill(noteColors.default);
        p.noStroke();
        p.rect(x, y, w, h);

        notesDrawn.add(noteKey);
      });
    });

    p.stroke(noteColors.border);
    for (let midi = pianoRollSetting.minMidi; midi <= pianoRollSetting.maxMidi; midi += 12) {
      const y = p.map(midi, pianoRollSetting.minMidi, pianoRollSetting.maxMidi, p.height, 0);
      p.line(0, y, p.width, y);
    }

    p.pop();
  };

  return <Sketch setup={setup} draw={draw} />;
};

export default PianoRoll;
