// src/components/ControlPanel.tsx
import React from "react";

type Props = {
  isPlaying: boolean;
  bpm: number;
  onStart: () => void;
  onStop: () => void;
  onChangeBPM: (value: number) => void;
};

const ControlPanel: React.FC<Props> = ({ isPlaying, bpm, onStart, onStop, onChangeBPM }) => {
  return (
    <div style={{ marginBottom: "20px" }}>
      <label>
        Visual BPM:
        <input
          type="range"
          min="60"
          max="240"
          step="1"
          value={bpm}
          onChange={(e) => onChangeBPM(Number(e.target.value))}
        />
        {bpm}
      </label>
      <div>
        {!isPlaying ? (
          <button onClick={onStart}>Start</button>
        ) : (
          <button onClick={onStop}>Stop</button>
        )}
      </div>
    </div>
  );
};

export default ControlPanel;
