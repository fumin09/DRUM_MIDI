// src/components/MIDIUpload.tsx
import React, { useEffect, useState } from "react";
import { Midi } from "@tonejs/midi";
import { openDB } from "idb";

// IndexedDB settings
const DB_NAME = "midiDB";
const STORE_NAME = "midiFiles";
const KEY = "userMidi";

// IndexedDB Save
export const saveToIndexedDB = async (buffer: ArrayBuffer) => {
  const db = await openDB(DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    },
  });
  await db.put(STORE_NAME, buffer, KEY);
};

// IndexedDB Load
export const loadFromIndexedDB = async (): Promise<ArrayBuffer | null> => {
  const db = await openDB(DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    },
  });
  return (await db.get(STORE_NAME, KEY)) ?? null;
};

const MIDIUpload: React.FC = () => {
  const [midi, setMidi] = useState<Midi | null>(null);

  // ファイルアップロード時の処理
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const arrayBuffer = await file.arrayBuffer();
    await saveToIndexedDB(arrayBuffer);
    const midi = new Midi(arrayBuffer);
    setMidi(midi);
    console.log("Uploaded MIDI:", midi);
  };

  // ページ読み込み時に保存済みMIDIを読み込み
  useEffect(() => {
    const loadSaved = async () => {
      const savedBuffer = await loadFromIndexedDB();
      if (savedBuffer) {
        const savedMidi = new Midi(savedBuffer);
        setMidi(savedMidi);
        console.log("Loaded saved MIDI:", savedMidi);
      }
    };
    loadSaved();
  }, []);

  return (
    <div style={{ marginBottom: "20px" }}>
      <label htmlFor="midi-upload">MIDIファイルをアップロード:</label>
      <input
        id="midi-upload"
        type="file"
        accept=".mid"
        onChange={handleFileUpload}
      />
    </div>
  );
};

export default MIDIUpload;